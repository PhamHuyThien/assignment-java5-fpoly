### v1.6
- thêm gửi email khi đăng kí tk mới thành công!
- thêm checkbox ghi nhớ mât khẩu đăng nhâp
- fix lỗi xóa giảm số lượng item đến xóa mà k giảm cart+ order
- thêm xóa account trong account manager (admin)

### v1.5
- sử dụng iterceptor thay webFilter (VIP VL)
- sử dụng cookie cho toàn trang thay vì dùng session như trước
- 
### v1.4
- [Lỗi nặng] fix lỗi nguy hiểm khiến các dân chơi có thể đổi pass bất cứ tk nào
- Gửi mail khi đặt hàng thành công!
- Gửi mail khi đổi mật khẩu ( báo đổi pass giống fb)
- Đổi mật khẩu sẽ tự động đăng xuất
### v1.3
- sử dụng titles để quản lý layout
- thêm chỉnh sửa thông tin cá nhân (account)
### v1.2
- chỉnh sửa lại giao diện cho đẹp hơn
- fix lại các form taglib tự động fill dữ liệu
- thêm quản lý tài khoản cho admin