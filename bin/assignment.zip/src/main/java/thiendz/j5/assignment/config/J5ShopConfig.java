/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thiendz.j5.assignment.config;

/**
 *
 * @author PhamHuyThien
 */
public class J5ShopConfig {
    public static final int LOGIN_TIME_REMEMBER_ME = 24;
    public static final int LOGIN_TIME_NO_REMEMBER_ME = 1;
}
